import logging

import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch
import random

import torchmetrics
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader

from datasets import *


def model_init(model: nn.Module, init_method: str) -> None:
    """
    Initialize sequential model's linear layer parameters
    """

    init = None
    if init_method == "XAVIER_UNIFORM":
        init = nn.init.xavier_uniform_
    elif init_method == "XAVIER_NORM":
        init = nn.init.xavier_normal_
    elif init_method == "KAIMING_UNIFORM":
        init = nn.init.kaiming_uniform_
    elif init_method == "KAIMING_NORM":
        init = nn.init.kaiming_normal_

    for layer in model.children():
        if isinstance(layer, nn.Linear) and init is not None:
            init(layer.weight)


def predict(model: nn.Module, data: TensorDataset) -> torch.tensor:
    data = DataLoader(data, batch_size=64, shuffle=False)
    outputs = []

    with torch.no_grad():
        for x, y in data:
            x_pre = model(x)
            outputs.append(x_pre)

    data_pre = torch.cat(outputs, dim=0)
    data_pre = F.softmax(data_pre, dim=1)
    return data_pre


def predict_sort(model: nn.Module, data: TensorDataset) -> torch.tensor:
    data = DataLoader(data, batch_size=64, shuffle=False)
    outputs = []

    with torch.no_grad():
        for x, y in data:
            x_pre = model(x)
            outputs.append(x_pre)

    data_pre = torch.cat(outputs, dim=0)
    data_pre = F.softmax(data_pre, dim=1)
    data_pre = torch.sort(data_pre, dim=1, descending=True).values
    return data_pre


def get_logger(file_path):
    """ Make python logger """
    # [!] Since tensorboardX use default logger (e.g. logging.info()), we should use custom logger
    logger = logging.getLogger('mia')
    logger.propagate = False
    log_format = '%(asctime)s | %(message)s'
    formatter = logging.Formatter(log_format, datefmt='%m/%d %I:%M:%S %p')
    file_handler = logging.FileHandler(file_path, encoding='utf-8')
    file_handler.setFormatter(formatter)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    logger.setLevel(logging.INFO)
    return logger


def train_nn_attack(model, tr_data, a_epochs, a_step_size, a_batch_size, a_learning_rate):
    """
    train a nn attack model on 'tr_data'
    """
    data_size = len(tr_data)
    tr_data = DataLoader(tr_data, batch_size=a_batch_size, shuffle=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=a_learning_rate)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=a_step_size, gamma=0.3)
    loss_fn = nn.BCEWithLogitsLoss()
    max_correct = 0

    for epoch in range(a_epochs):
        for x, y in tr_data:
            pred = model(x)
            loss = loss_fn(pred, y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        scheduler.step()

        with torch.no_grad():
            sum_loss = 0
            sum_correct = 0
            for x, y in tr_data:
                pred_logits = model(x)
                pred = torch.sigmoid(pred_logits)
                loss = loss_fn(pred_logits, y)

                sum_loss += loss.item()
                sum_correct += ((pred > 0.5) == (y > 0.5)).type(torch.float).sum().item()
            sum_loss /= len(tr_data)
            sum_correct /= data_size
            print("Epoch: " + str(
                epoch) + f" NN attack train Accuracy: {(100 * sum_correct):>0.1f}%, Avg loss: {sum_loss:>8f}")


def test_nn_attack(model, data, device):
    """
    test nn attack model's performance on 'te_data'
    """
    data = DataLoader(data, batch_size=128, shuffle=True)
    accuracy = torchmetrics.Accuracy(multiclass=False, task='binary').to(device)
    precision = torchmetrics.Precision(multiclass=False, task='binary').to(device)
    recall = torchmetrics.Recall(multiclass=False, task='binary').to(device)
    f1_score = torchmetrics.F1Score(multiclass=False, task='binary').to(device)

    with torch.no_grad():
        for x, y in data:
            pred = torch.sigmoid(model(x))
            accuracy.update(pred, y)
            precision.update(pred, y)
            recall.update(pred, y)
            f1_score.update(pred, y)

    total_acc = accuracy.compute()
    total_precision = precision.compute()
    total_recall = recall.compute()
    total_f1 = f1_score.compute()

    print(f"Accuracy :{100 * total_acc:> 0.2f}%, Precision :{100 * total_precision:> 0.2f}%, "
          f"Recall :{100 * total_recall:> 0.2f}%, F1 Score :{100 * total_f1:> 0.2f}%")


if __name__ == "__main__":

    print('----')
