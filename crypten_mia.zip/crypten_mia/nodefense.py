import crypten
import crypten.communicator as comm
from datasets import *
from models import *
from utils import *

ALICE = 0
BOB = 1
START_NEW = True
DEVICE = torch.device("cuda:0")


def mpc_nodefense_train(data_name, model_name):
    rank = comm.get().get_rank()

    # Read nodefense model's train parameters
    nodefense_model_config = configparser.ConfigParser()
    nodefense_model_config.read('nodefense_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_nodefense_train start!')

    epochs = int(nodefense_model_config['{}_{}'.format(data_name, model_name)]['EPOCHS'])
    batch_size = int(nodefense_model_config['{}_{}'.format(data_name, model_name)]['BATCH_SIZE'])
    learning_rate = float(nodefense_model_config['{}_{}'.format(data_name, model_name)]['LEARNING_RATE'])
    num_class = int(nodefense_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = nodefense_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    step_size = int(nodefense_model_config['{}_{}'.format(data_name, model_name)]['STEP_SIZE'])
    gamma = float(nodefense_model_config['{}_{}'.format(data_name, model_name)]['GAMMA'])

    model_path = "models/nodefense/{}_{}.pth".format(data_name, model_name)

    # In this single machine situation, all processes have access to all data,
    raw_data_x, raw_data_y = globals()[data_name]()
    input_shape = raw_data_x[0].shape
    if rank == 0:
        alice_dict = get_alice_split(raw_data_x, raw_data_y, data_name)
        data_x, data_y = alice_dict["train"]
        data_y = torch.eye(num_class)[data_y]
        test_x, test_y = alice_dict["test"]
        test_y = torch.eye(num_class)[test_y]
    else:
        bob_dict = get_bob_split(raw_data_x, raw_data_y, data_name)
        data_x, data_y = bob_dict["train"]
        data_y = torch.eye(num_class)[data_y]
        test_x, test_y = bob_dict["test"]
        test_y = torch.eye(num_class)[test_y]

    # Secret share each party's own data
    alice_data_x = crypten.cryptensor(data_x, src=ALICE)
    alice_data_y = crypten.cryptensor(data_y, src=ALICE)

    bob_data_x = crypten.cryptensor(data_x, src=BOB)
    bob_data_y = crypten.cryptensor(data_y, src=BOB)

    alice_test_x = crypten.cryptensor(test_x, src=ALICE)
    alice_test_y = crypten.cryptensor(test_y, src=ALICE)

    bob_test_x = crypten.cryptensor(test_x, src=BOB)
    bob_test_y = crypten.cryptensor(test_y, src=BOB)

    data_x_enc = crypten.cat([alice_data_x, bob_data_x], dim=0)
    data_x_enc = data_x_enc.to(DEVICE)
    data_y_enc = crypten.cat([alice_data_y, bob_data_y], dim=0)
    data_y_enc = data_y_enc.to(DEVICE)
    test_x_enc = crypten.cat([alice_test_x, bob_test_x], dim=0)
    test_x_enc = test_x_enc.to(DEVICE)
    test_y_enc = crypten.cat([alice_test_y, bob_test_y], dim=0)
    test_y_enc = test_y_enc.to(DEVICE)

    # train nodefense model encrypted
    dummy_input = torch.empty([1] + list(input_shape))
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    # model_state_dict = torch.load(model_path)
    # model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE)
    model_enc = model_enc.to(DEVICE)
    private_train_encrypted(data_x_enc, data_y_enc, model_enc, epochs, batch_size, learning_rate, step_size, gamma, model_path, logger)

    # test nodefense model's accuracy on test data
    test_encrypted(test_x_enc, test_y_enc, model_enc, logger)

    predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, num_class, init_method, logger)


def private_train_encrypted(data_x_enc, data_y_enc, model_enc, num_epochs, batch_size, learning_rate, step_size, gamma,
                            save_path, logger):
    rank = comm.get().get_rank()
    loss_fn = crypten.nn.CrossEntropyLoss().to(DEVICE)
    num_samples = data_x_enc.shape[0]
    model_enc.train()

    for epoch in range(num_epochs):

        correct_count = 0
        loss_count = 0
        if epoch + 1 % step_size == 0:
            learning_rate *= gamma

        for index in range(0, num_samples, batch_size):

            # Get data batch
            start, end = index, min(index + batch_size, num_samples)
            x_train = data_x_enc[start:end]
            y_train = data_y_enc[start:end]
            x_train.requires_grad = True
            y_train.requires_grad = True

            # forward propagation
            output = model_enc(x_train)
            loss_value = loss_fn(output, y_train)

            # backward propagation
            model_enc.zero_grad()
            loss_value.backward()
            model_enc.update_parameters(learning_rate)

            # Compute model's accuracy in this epoch
            # Only use this in test environment
            pred = output.get_plain_text().argmax(1)
            data_y = y_train.get_plain_text().argmax(1)
            correct_count += pred.eq(data_y).sum().float().item()
            loss_count += loss_value.get_plain_text().item()
            if rank == 0:
                logger.info(f'{index}/{num_samples} done!')

        if rank == 0:
            if rank == 0:
                logger.info("Epoch: " + str(epoch + 1) + f" Accuracy: {(100 * correct_count / num_samples):>0.1f}%,"
                                                         f" Avg loss: {loss_count * batch_size / num_samples:>8f}")

        if save_path is not None:
            # max_correct = correct_count / num_samples
            # save plain text private model
            model_enc.decrypt()
            model_pri_state_dict = model_enc.state_dict()
            pri_num = save_path.find('nodefense/') + len('nodefense')
            mid_num = save_path.find('.pth')
            if epoch + 1 < 10:
                end_path = f'_epoch[0{epoch + 1}]_acc[{(100 * correct_count / num_samples):>0.1f}]_loss[{loss_count * batch_size / num_samples:>8f}].pth'
            else:
                end_path = f'_epoch[{epoch + 1}]_acc[{(100 * correct_count / num_samples):>0.1f}]_loss[{loss_count * batch_size / num_samples:>8f}].pth'
            path = save_path[:pri_num] + '/epoch_models' + save_path[pri_num:mid_num] + end_path
            if rank == ALICE:
                # torch.save(model_pri_state_dict, path)
                torch.save(model_pri_state_dict, save_path)
            model_enc.encrypt(src=ALICE)

    return model_enc


def test_encrypted(data_x_enc, data_y_enc, model_enc, logger):
    rank = comm.get().get_rank()
    num_samples = data_x_enc.shape[0]
    model_enc.eval()

    correct_count = 0
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]
        y_train = data_y_enc[start:end]

        # forward propagation
        output = model_enc(x_train)

        # compute accuracy
        pred = output.get_plain_text().argmax(1)
        data_y = y_train.get_plain_text().argmax(1)
        correct_count += pred.eq(data_y).sum().float().item()
        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    if rank == 0:
        logger.info(f"Test accuracy: {(100 * correct_count / num_samples):>0.1f}%")


def eval_encrypted(data_x_enc, model_enc, logger):
    rank = comm.get().get_rank()

    model_enc.eval()
    num_samples = data_x_enc.shape[0]
    outputs = []
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]

        # forward propagation
        output = model_enc(x_train)
        outputs.append(output)

        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    return crypten.cat(outputs, dim=0)


def predict_encrypted(data_x, data_y, data_name, model_name, num_class, init_method, logger):
    rank = comm.get().get_rank()
    if rank == 0:
        logger.info('predict_encrypted start!')

    # load data need to be predicted
    input_shape = data_x[0].shape
    train_data_x, train_data_y = get_train_predict_split(data_x, data_y, data_name)
    # train_data_x, train_data_y = get_ref(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE)
    train_x_enc = train_x_enc.to(DEVICE)

    # load saved model
    dummy_input = torch.empty([1] + list(input_shape))
    if rank == 0:
        logger.info('load saved model')
    model_path = "models/nodefense/{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/nodefense/train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/nodefense/train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)


def mpc_nodefense_predict(data_name, model_name):
    rank = comm.get().get_rank()

    # Read nodefense model's parameters
    nodefense_model_config = configparser.ConfigParser()
    nodefense_model_config.read('nodefense_config.ini')
    num_class = int(nodefense_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = nodefense_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    logger = get_logger('./logger/{}_{}'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_nodefense_predict start!')

    # load data need to be predicted
    data_x, data_y = globals()[data_name]()
    input_shape = data_x[0].shape

    train_data_x, train_data_y = get_train_predict_split(data_x, data_y, data_name)
    # train_data_x, train_data_y = get_ref(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE)
    train_x_enc = train_x_enc.to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/nodefense/{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/nodefense/train_pred_{}_{}_raw.pth".format(data_name, model_name)
    train_y_path = "results/nodefense/train_y_{}_{}_raw.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)
