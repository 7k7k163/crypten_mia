import argparse
import os

from launcher_test import MultiProcessLauncher
from test_utils import predict_test_all_data


def validate_world_size(world_size):
    world_size = int(world_size)
    if world_size < 2:
        raise argparse.ArgumentTypeError(f"world_size {world_size} must be > 1")
    return world_size


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mpc_job",
        type=str,
        default="predict_test_all_data",
        help="The function will be run in secure multiply party computation",
    )

    parser.add_argument(
        "--scheme",
        type=str,
        default="nodefense",
        help="",
    )

    parser.add_argument(
        "--data",
        type=str,
        default="ch_mnist",
        help="The data name will be used(ch_mnist, location)",
    )

    parser.add_argument(
        "--model",
        type=str,
        default="lenet",
        help="The model name will be used(lenet, cnn2 for ch_mnist, dense_layer4 for location)",
    )

    parser.add_argument(
        "--world_size",
        type=validate_world_size,
        default=2,
        help="The number of parties to launch. Each party acts as its own process",
    )

    args = parser.parse_args()

    mpc_job = globals()[args.mpc_job]

    launcher = MultiProcessLauncher(mpc_job, args.world_size, args.scheme, args.data, args.model)
    launcher.start()
    launcher.join()
    launcher.terminate()


if __name__ == "__main__":
    cwd = os.getcwd()
    num = cwd.find('test')-1
    os.chdir(cwd[:num])
    main()
