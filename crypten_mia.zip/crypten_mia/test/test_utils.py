import numpy as np
import crypten
import crypten.communicator as comm
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
import torch.nn.functional as F
import random
import configparser
import logging
from datasets import *

ALICE = 0
BOB = 1
DEVICE = torch.device("cuda:0")


def get_logger(file_path):
    """ Make python logger """
    # [!] Since tensorboardX use default logger (e.g. logging.info()), we should use custom logger
    logger = logging.getLogger('mia')
    logger.propagate = False
    log_format = '%(asctime)s | %(message)s'
    formatter = logging.Formatter(log_format, datefmt='%m/%d %I:%M:%S %p')
    file_handler = logging.FileHandler(file_path, encoding='utf-8')
    file_handler.setFormatter(formatter)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    logger.setLevel(logging.INFO)
    return logger


def predict(model: nn.Module, data: Tensor) -> torch.tensor:
    model.eval()
    num_samples = data.shape[0]
    outputs = []

    for index in range(0, num_samples, 64):
        start, end = index, min(index + 64, num_samples)
        x_train = data[start:end]
        output = model(x_train)
        outputs.append(output)

    data_pre = torch.cat(outputs, dim=0)
    return data_pre


def get_test_ensemble_model(scheme, data_name, model_name, input_shape, num_class, init_method, dummy_input):
    if scheme == "ensemble":
        model_path1 = "models/ensemble/base_{}_{}_1.pth".format(data_name, model_name)
        model_path2 = "models/ensemble/base_{}_{}_2.pth".format(data_name, model_name)
        model_path3 = "models/ensemble/base_{}_{}_3.pth".format(data_name, model_name)
        model1 = globals()[model_name](input_shape, num_class, init_method)
        model_enc1 = crypten.nn.from_pytorch(model1, dummy_input)
        model_state_dict1 = torch.load(model_path1)
        model_enc1.load_state_dict(model_state_dict1)
        model_enc1.encrypt(src=ALICE)
        model_enc1 = model_enc1.to(DEVICE)

        model2 = globals()[model_name](input_shape, num_class, init_method)
        model_enc2 = crypten.nn.from_pytorch(model2, dummy_input)
        model_state_dict2 = torch.load(model_path2)
        model_enc2.load_state_dict(model_state_dict2)
        model_enc2.encrypt(src=ALICE)
        model_enc2 = model_enc2.to(DEVICE)

        model3 = globals()[model_name](input_shape, num_class, init_method)
        model_enc3 = crypten.nn.from_pytorch(model3, dummy_input)
        model_state_dict3 = torch.load(model_path3)
        model_enc3.load_state_dict(model_state_dict3)
        model_enc3.encrypt(src=ALICE)
        model_enc3 = model_enc3.to(DEVICE)
        return model_enc1, model_enc2, model_enc3
    else:
        return None


def get_test_model(scheme, data_name, model_name, input_shape, num_class, init_method, dummy_input):
    model_path = None
    if scheme == "nodefense":
        model_path = "models/nodefense/{}_{}.pth".format(data_name, model_name)
    elif scheme == "shadow":
        model_path = "models/shadow/{}_{}.pth".format(data_name, model_name)
    elif scheme == "distillation":
        model_path = "models/distillation/student_{}_{}.pth".format(data_name, model_name)
        if model_name.find('dense') != -1:
            model_name = model_name + '_student'
    elif scheme == "ensemble_protected":
        model_path = "models/ensemble/ensemble_protected_{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE)
    model_enc = model_enc.to(DEVICE)
    return model_enc


def get_final_predict_data(model_1, model_2, model_3, data_y):
    name_of_models = ['model1', 'model2', 'model3']
    num_flag = [1, 2, 4, 8, 16]
    outputs = dict()
    outputs[name_of_models[0]] = model_1
    outputs[name_of_models[1]] = model_2
    outputs[name_of_models[2]] = model_3
    outputs_flag = dict()
    for name in outputs.keys():
        outputs_flag[name] = torch.argmax(outputs[name], dim=1) == data_y
    flag = torch.zeros(len(data_y))
    num = 0
    for name in outputs_flag.keys():
        for idx in range(len(outputs[name])):
            if outputs_flag[name][idx].item():
                flag[idx] += num_flag[num]
        num += 1
    data_pre = torch.zeros(model_1.size()[0], model_1.size()[1])
    for idx in range(len(model_1)):
        if flag[idx] == 7:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[1]][idx] +
                             outputs[name_of_models[0]][
                                 idx]) / 3.0
        elif flag[idx] == 6:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[1]][idx]) / 2.0
        elif flag[idx] == 5:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[0]][idx]) / 2.0
        elif flag[idx] == 4:
            data_pre[idx] = outputs[name_of_models[2]][idx]
        elif flag[idx] == 3:
            data_pre[idx] = (outputs[name_of_models[1]][idx] + outputs[name_of_models[0]][idx]) / 2.0
        elif flag[idx] == 2:
            data_pre[idx] = outputs[name_of_models[1]][idx]
        elif flag[idx] == 1:
            data_pre[idx] = outputs[name_of_models[0]][idx]
        elif flag[idx] == 0:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[1]][idx] +
                             outputs[name_of_models[0]][
                                 idx]) / 3.0
    return F.softmax(data_pre, dim=1).to(DEVICE)


def predict_test(scheme, data_name, model_name):
    rank = comm.get().get_rank()

    config = configparser.ConfigParser()
    if scheme.find('_protected') != -1:
        raw_scheme = scheme[:scheme.find('_protected')]
    else:
        raw_scheme = scheme
    config.read(f'{raw_scheme}_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info(f'mpc_{scheme}_test start!')


    num_class = int(config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']

    raw_data_x, raw_data_y = globals()[data_name]()
    random_sample = random.sample(range(len(raw_data_y)), 10)
    test_data_x = raw_data_x[random_sample].to(DEVICE)
    test_data_y = raw_data_y[random_sample].to(DEVICE)
    test_data_x_enc = crypten.cryptensor(test_data_x, src=ALICE).to(DEVICE)
    # test_data_y_enc = crypten.cryptensor(test_data_y, src=ALICE)

    input_shape = raw_data_x[0].shape
    dummy_input = torch.empty([1] + list(input_shape))
    if scheme == 'ensemble':
        test_model1, test_model2, test_model3 = get_test_ensemble_model(scheme, data_name, model_name, input_shape, num_class, init_method, dummy_input)
        predict_data_y_1 = predict(test_model1, test_data_x_enc)
        predict_data_y_2 = predict(test_model2, test_data_x_enc)
        predict_data_y_3 = predict(test_model3, test_data_x_enc)
        predict_data_y_plain_1 = predict_data_y_1.get_plain_text()
        predict_data_y_plain_2 = predict_data_y_2.get_plain_text()
        predict_data_y_plain_3 = predict_data_y_3.get_plain_text()

        predict_data_y_plain = get_final_predict_data(predict_data_y_plain_1, predict_data_y_plain_2, predict_data_y_plain_3, test_data_y)
        predict_result = predict_data_y_plain.argmax(1).eq(test_data_y)
    else:
        test_model = get_test_model(scheme, data_name, model_name, input_shape, num_class, init_method, dummy_input)
        predict_data_y = predict(test_model, test_data_x_enc)
        predict_data_y_plain = predict_data_y.get_plain_text()
        predict_data_y_plain = F.softmax(predict_data_y_plain, dim=1)
        predict_result = predict_data_y_plain.argmax(1).eq(test_data_y)

    for idx in range(len(test_data_y)):
        if rank == 0:
            if predict_result[idx]:
                logger.info(f'样本预测向量：{predict_data_y_plain[idx]}，预测标签：{predict_data_y_plain[idx].argmax(-1)}，样本标签：{test_data_y[idx]}，预测正确！')
            else:
                logger.info(f'样本预测向量：{predict_data_y_plain[idx]}，预测标签：{predict_data_y_plain[idx].argmax(-1)}，样本标签：{test_data_y[idx]}，预测错误！')
    if rank == 0:
        logger.info(f'预测准确度：{100 * predict_result.sum().float().item() / len(test_data_y)}%')


def predict_test_all_data(scheme, data_name, model_name):
    rank = comm.get().get_rank()

    config = configparser.ConfigParser()
    if scheme.find('_protected') != -1:
        raw_scheme = scheme[:scheme.find('_protected')]
    else:
        raw_scheme = scheme
    config.read(f'{raw_scheme}_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info(f'mpc_{scheme}_test start!')

    num_class = int(config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']

    raw_data_x, raw_data_y = globals()[data_name]()
    if rank == 0:
        alice_dict = get_alice_split(raw_data_x, raw_data_y, data_name)
        test_x, test_y = alice_dict["test"]
        test_y = torch.eye(num_class)[test_y]
    else:
        bob_dict = get_bob_split(raw_data_x, raw_data_y, data_name)
        test_x, test_y = bob_dict["test"]
        test_y = torch.eye(num_class)[test_y]

    # Secret share each party's own data
    alice_test_x = crypten.cryptensor(test_x, src=ALICE)
    alice_test_y = crypten.cryptensor(test_y, src=ALICE)

    bob_test_x = crypten.cryptensor(test_x, src=BOB)
    bob_test_y = crypten.cryptensor(test_y, src=BOB)

    test_x_enc = crypten.cat([alice_test_x, bob_test_x], dim=0)
    test_data_x_enc = test_x_enc.to(DEVICE)
    test_y_enc = crypten.cat([alice_test_y, bob_test_y], dim=0)
    test_data_y = torch.argmax(test_y_enc.get_plain_text(), dim=1).to(DEVICE)

    input_shape = raw_data_x[0].shape
    dummy_input = torch.empty([1] + list(input_shape))
    if scheme == 'ensemble':
        test_model1, test_model2, test_model3 = get_test_ensemble_model(scheme, data_name, model_name, input_shape, num_class, init_method, dummy_input)
        predict_data_y_1 = predict(test_model1, test_data_x_enc)
        predict_data_y_2 = predict(test_model2, test_data_x_enc)
        predict_data_y_3 = predict(test_model3, test_data_x_enc)
        predict_data_y_plain_1 = predict_data_y_1.get_plain_text()
        predict_data_y_plain_2 = predict_data_y_2.get_plain_text()
        predict_data_y_plain_3 = predict_data_y_3.get_plain_text()

        predict_data_y_plain = get_final_predict_data(predict_data_y_plain_1, predict_data_y_plain_2, predict_data_y_plain_3, test_data_y)
        predict_result = predict_data_y_plain.argmax(1).eq(test_data_y)
    else:
        test_model = get_test_model(scheme, data_name, model_name, input_shape, num_class, init_method, dummy_input)
        predict_data_y = predict(test_model, test_data_x_enc)
        predict_data_y_plain = predict_data_y.get_plain_text()
        predict_data_y_plain = F.softmax(predict_data_y_plain, dim=1)
        predict_result = predict_data_y_plain.argmax(1).eq(test_data_y)

    if rank == 0:
        logger.info(f'预测准确度：{100 * predict_result.sum().float().item() / len(test_data_y)}%')
