import configparser
import os
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from torch import Tensor

from models import *


def ch_mnist(norm=True) -> Tuple[torch.Tensor, torch.Tensor]:
    ch_mnist_data = pd.read_csv('dataset/ch_mnist/hmnist_64_64_L.csv')
    data_x = ch_mnist_data.iloc[:, range(0, 4096)].values
    if norm:
        data_x = data_x / 256.0
    data_x = data_x.reshape(-1, 1, 64, 64)
    data_y = np.array([i - 1 for i in ch_mnist_data.iloc[:, 4096]])

    if os.path.exists("dataset/ch_mnist/shuffle.npy"):
        indices = np.load("dataset/ch_mnist/shuffle.npy")
    else:
        indices = np.arange(len(data_y))
        np.random.shuffle(indices)
        np.save("dataset/ch_mnist/shuffle.npy", indices)

    data_x = data_x[indices]
    data_y = data_y[indices]

    data_x = torch.from_numpy(data_x).type(torch.FloatTensor)
    data_y = torch.from_numpy(data_y).type(torch.LongTensor)

    return data_x, data_y


def location() -> Tuple[torch.Tensor, torch.Tensor]:
    npz_data = np.load("dataset/location/data_complete.npz")
    data_x = npz_data['x'][:, :]
    data_y = npz_data['y'][:]

    if os.path.exists("dataset/location/shuffle.npy"):
        indices = np.load("dataset/location/shuffle.npy")
    else:
        indices = np.arange(len(data_y))
        np.random.shuffle(indices)
        np.save("dataset/location/shuffle.npy", indices)

    data_x = data_x[indices]
    data_y = data_y[indices]
    data_y = data_y - 1.0

    data_x = torch.from_numpy(data_x).type(torch.FloatTensor)
    data_y = torch.from_numpy(data_y).type(torch.LongTensor)

    return data_x[:5000], data_y[:5000]


def get_alice_split(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Dict[
    str, Tuple[torch.Tensor, torch.Tensor]]:
    dataset_config = configparser.ConfigParser()
    dataset_config.read('dataset.ini')
    # start = 0
    # end = int(dataset_config[data_name]['ALICE_SIZE'])

    # alice_data_x, alice_data_y = data_x[start:end], data_y[start:end]
    sample_size = int(dataset_config[data_name]['ALICE_SIZE'])
    train_size = round(sample_size * float(dataset_config[data_name]['TRAIN_RATIO']))
    ref_size = round(sample_size * float(dataset_config[data_name]['REF_RATIO']))
    test_size = round(sample_size * float(dataset_config[data_name]['TEST_RATIO']))

    train_x, train_y = data_x[0:train_size], data_y[0:train_size]
    ref_x, ref_y = data_x[-2 * ref_size:-ref_size], data_y[-2 * ref_size:-ref_size]
    test_x = data_x[2 * train_size:2 * train_size + test_size]
    test_y = data_y[2 * train_size:2 * train_size + test_size]

    return {"train": (train_x, train_y), "ref": (ref_x, ref_y), "test": (test_x, test_y)}


def get_bob_split(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Dict[
    str, Tuple[torch.Tensor, torch.Tensor]]:
    dataset_config = configparser.ConfigParser()
    dataset_config.read('dataset.ini')
    # start = int(dataset_config[data_name]['ALICE_SIZE'])
    # end = start + int(dataset_config[data_name]['BOB_SIZE'])

    # bob_data_x, bob_data_y = data_x[start:end], data_y[start:end]
    sample_size = int(dataset_config[data_name]['BOB_SIZE'])
    train_size = round(sample_size * float(dataset_config[data_name]['TRAIN_RATIO']))
    ref_size = round(sample_size * float(dataset_config[data_name]['REF_RATIO']))
    test_size = round(sample_size * float(dataset_config[data_name]['TEST_RATIO']))

    train_x, train_y = data_x[train_size:2 * train_size], data_y[train_size:2 * train_size]
    ref_x, ref_y = data_x[-ref_size:], data_y[-ref_size:]
    test_x = data_x[2 * train_size + test_size:2 * train_size + 2 * test_size]
    test_y = data_y[2 * train_size + test_size:2 * train_size + 2 * test_size]

    return {"train": (train_x, train_y), "ref": (ref_x, ref_y), "test": (test_x, test_y)}


def get_nn_split(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Dict[
    str, Tuple[torch.Tensor, torch.Tensor]]:
    dataset_config = configparser.ConfigParser()
    dataset_config.read('dataset.ini')
    start = (int(dataset_config[data_name]['ALICE_SIZE']) + int(dataset_config[data_name]['BOB_SIZE'])) * 2 // 3
    end = start + int(dataset_config[data_name]['NN_SIZE'])
    middle = (start + end) // 2
    train_x, train_y = data_x[start:middle], data_y[start:middle]
    test_x, test_y = data_x[middle:end], data_y[middle:end]

    return {"train": (train_x, train_y), "test": (test_x, test_y)}


def get_sample_split(data_x, data_y, data_name: str):
    alice_data = data_x['train']
    bob_data = data_y['train']
    raw_train_x = torch.cat([alice_data[0], bob_data[0]], dim=0)
    raw_train_y = torch.cat([alice_data[1], bob_data[1]], dim=0)
    dataset_config = configparser.ConfigParser()
    dataset_config.read('dataset.ini')
    num_of_data = (int(dataset_config[data_name]['ALICE_SIZE']) + int(dataset_config[data_name]['BOB_SIZE'])) // 3
    indices = np.random.choice(num_of_data, num_of_data)
    indices.sort()
    train_x = []
    train_y = []
    for idx in indices:
        train_x.append(raw_train_x[idx])
        train_y.append(raw_train_y[idx])

    return train_x, train_y


def get_part_sample_split(data, data_name: str, part: str):
    data_x, data_y = data["train"]
    shape = data_x.shape
    dataset_config = configparser.ConfigParser()
    dataset_config.read('dataset.ini')
    num_of_data = 0
    if part == 'alice':
        num_of_data = (int(dataset_config[data_name]['ALICE_SIZE'])) // 3
    elif part == 'bob':
        num_of_data = (int(dataset_config[data_name]['BOB_SIZE'])) // 3
    indices = np.random.choice(num_of_data, num_of_data)
    indices.sort()
    train_x = []
    train_y = []
    for idx in indices:
        train_x.append(data_x[idx])
        train_y.append(data_y[idx])
    train_x = torch.cat(train_x, dim=0).view(shape)
    train_y = torch.tensor(train_y)

    return train_x, train_y


def get_train_predict_split(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Tuple[
    torch.Tensor, torch.Tensor]:
    alice_dict = get_alice_split(data_x, data_y, data_name)
    bob_dict = get_bob_split(data_x, data_y, data_name)

    train_data_x = torch.cat([alice_dict["train"][0], bob_dict["train"][0], alice_dict["test"][0], bob_dict["test"][0]],
                             dim=0)
    train_data_y = torch.cat([alice_dict["train"][1], bob_dict["train"][1], alice_dict["test"][1], bob_dict["test"][1]],
                             dim=0)

    return train_data_x, train_data_y


def get_ref_predict_split(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Tuple[
    torch.Tensor, torch.Tensor]:
    alice_dict = get_alice_split(data_x, data_y, data_name)
    bob_dict = get_bob_split(data_x, data_y, data_name)

    ref_data_x = torch.cat([alice_dict["ref"][0], bob_dict["ref"][0], alice_dict["test"][0], bob_dict["test"][0]],
                           dim=0)
    ref_data_y = torch.cat([alice_dict["ref"][1], bob_dict["ref"][1], alice_dict["test"][1], bob_dict["test"][1]],
                           dim=0)

    return ref_data_x, ref_data_y


def get_ref(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Tuple[
    torch.Tensor, torch.Tensor]:
    alice_dict = get_alice_split(data_x, data_y, data_name)
    bob_dict = get_bob_split(data_x, data_y, data_name)

    ref_data_x = torch.cat([alice_dict["ref"][0], bob_dict["ref"][0]], dim=0)
    ref_data_y = torch.cat([alice_dict["ref"][1], bob_dict["ref"][1]], dim=0)

    return ref_data_x, ref_data_y


def get_ref_split(data_x: torch.Tensor, data_y: torch.Tensor, data_name: str) -> Dict[str, Tuple[Tensor, Tensor]]:
    alice_dict = get_alice_split(data_x, data_y, data_name)
    bob_dict = get_bob_split(data_x, data_y, data_name)

    ref_data_x = torch.cat([alice_dict["train"][0], bob_dict["train"][0], alice_dict["ref"][0]], dim=0)
    ref_data_y = torch.cat([alice_dict["train"][1], bob_dict["train"][1], alice_dict["ref"][1]], dim=0)

    ref_test_x = torch.cat([alice_dict["test"][0], bob_dict["test"][0], bob_dict["ref"][0]], dim=0)
    ref_test_y = torch.cat([alice_dict["test"][1], bob_dict["test"][1], bob_dict["ref"][1]], dim=0)

    return {"ref": (ref_data_x, ref_data_y), "test": (ref_test_x, ref_test_y)}


if __name__ == "__main__":
    # data_x, data_y = ch_mnist()
    print('----')
