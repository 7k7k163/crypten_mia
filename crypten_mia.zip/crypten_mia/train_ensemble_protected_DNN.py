import argparse

from launcher import MultiProcessLauncher
from ensemble import mpc_ensemble_protected_train, mpc_ensemble_predict


def validate_world_size(world_size):
    world_size = int(world_size)
    if world_size < 2:
        raise argparse.ArgumentTypeError(f"world_size {world_size} must be > 1")
    return world_size


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mpc_job",
        type=str,
        default="mpc_ensemble_protected_train",
        help="The function will be run in secure multiply party computation",
    )

    parser.add_argument(
        "--data",
        type=str,
        default="location",
        help="The data name will be used",
    )

    parser.add_argument(
        "--model",
        type=str,
        default="dense_layer4",
        help="The model name will be used",
    )

    parser.add_argument(
        "--world_size",
        type=validate_world_size,
        default=2,
        help="The number of parties to launch. Each party acts as its own process",
    )

    args = parser.parse_args()

    mpc_job = globals()[args.mpc_job]

    launcher = MultiProcessLauncher(mpc_job, args.world_size, args.data, args.model)
    launcher.start()
    launcher.join()
    launcher.terminate()


if __name__ == "__main__":
    main()
