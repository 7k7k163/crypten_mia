import torch
import torch.nn as nn

from utils import model_init


def lenet(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    flatten_num = int(((input_shape[1] / 4 - 3) * (input_shape[2] / 4 - 3)) * 16)
    model = nn.Sequential(
        nn.Conv2d(input_shape[0], 6, (5, 5)),
        nn.MaxPool2d((2, 2)),
        nn.ReLU(),
        nn.Conv2d(6, 16, (5, 5)),
        nn.MaxPool2d((2, 2)),
        nn.ReLU(),
        nn.Flatten(),
        nn.Linear(flatten_num, 120),
        nn.ReLU(),
        nn.Linear(120, 84),
        nn.ReLU(),
        nn.Linear(84, num_classes)
    )
    model_init(model, init_method)
    return model


def cnn2(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    flatten_num = int(input_shape[1] * input_shape[2] * 0.5)
    model = nn.Sequential(
        nn.Conv2d(input_shape[0], 16, 3, padding=(1, 1)),
        nn.ReLU(),
        nn.MaxPool2d((2, 2)),
        nn.Conv2d(16, 8, 3, padding=(1, 1)),
        nn.ReLU(),
        nn.MaxPool2d((2, 2)),
        nn.Flatten(),
        nn.Linear(flatten_num, 128),
        nn.ReLU(),
        nn.Linear(128, num_classes)
    )
    model_init(model, init_method)
    return model


def dense_layer4(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    input_shape = input_shape[0]
    model = nn.Sequential(
        nn.Linear(input_shape, 1024),
        nn.ReLU(),
        nn.Linear(1024, 512),
        nn.ReLU(),
        nn.Linear(512, 256),
        nn.ReLU(),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, num_classes)
    )
    model_init(model, init_method)
    return model


def dense_layer4_teacher(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    input_shape = input_shape[0]
    model = nn.Sequential(
        nn.Linear(input_shape, 1024),
        nn.ReLU(),
        nn.Linear(1024, 512),
        nn.ReLU(),
        nn.Linear(512, 256),
        nn.ReLU(),
        nn.Linear(256, 256),
        nn.ReLU(),
        nn.Linear(256, num_classes)
    )
    model_init(model, init_method)
    return model


def dense_layer4_student(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    input_shape = input_shape[0]
    model = nn.Sequential(
        nn.Linear(input_shape, 1024),
        nn.ReLU(),
        nn.Linear(1024, 512),
        nn.ReLU(),
        nn.Linear(512, 256),
        nn.ReLU(),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, num_classes)
    )
    model_init(model, init_method)
    return model


def dense_layer2_teacher(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    input_shape = input_shape[0]
    model = nn.Sequential(
        nn.Linear(input_shape, 512),
        nn.ReLU(),
        nn.Linear(512, 256),
        nn.ReLU(),
        nn.Linear(256, num_classes)
    )
    model_init(model, init_method)
    return model


def dense_layer2_student(input_shape: torch.Tensor, num_classes: int, init_method: str) -> nn.Module:
    input_shape = input_shape[0]
    model = nn.Sequential(
        nn.Linear(input_shape, 512),
        nn.ReLU(),
        nn.Linear(512, 128),
        nn.ReLU(),
        nn.Linear(128, num_classes)
    )
    model_init(model, init_method)
    return model


def nn_attack_dropout(input_dim: int, init_method: str, num_classes: int = 1) -> nn.Module:
    model = nn.Sequential(
        nn.Linear(input_dim, 512),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(512, 256),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Linear(128, num_classes)
    )
    model_init(model, init_method)
    return model


if __name__ == "__main__":
    # model = lenet(torch.tensor((1, 64, 64)), 8, 'XAVIER_UNIFORM')
    print('---')
