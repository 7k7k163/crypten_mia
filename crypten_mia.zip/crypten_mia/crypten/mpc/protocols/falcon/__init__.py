"""SecureNN Protocol."""

from .falcon_protocol import FalconProtocol

__all__ = ["FalconProtocol"]