"""FSS Protocol."""

from .fss_protocol import FSSProtocol

__all__ = ["FSSProtocol"]
