from .spdz_protocol import SPDZProtocol

__all__ = ["SPDZProtocol"]
