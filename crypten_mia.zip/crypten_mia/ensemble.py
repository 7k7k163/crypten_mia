import time

import torch
from torch.utils.data import DataLoader
import crypten
import crypten.communicator as comm
from datasets import *
from models import *
from utils import get_logger

ALICE = 0
BOB = 1
START_NEW = True
DEVICE = torch.device("cuda:0")


def mpc_ensemble_protected_train(data_name, model_name):
    rank = comm.get().get_rank()

    # Read ensemble model's train parameters
    ensemble_model_config = configparser.ConfigParser()
    ensemble_model_config.read('ensemble_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_ensemble_protected_train start!')

    pri_epochs = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PRI_EPOCHS'])
    pub_epochs = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PUB_EPOCHS'])
    pub_pre_epochs = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PUB_PRE_EPOCHS'])
    batch_size = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['BATCH_SIZE'])
    pri_learning_rate = float(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PRI_LEARNING_RATE'])
    pub_learning_rate = float(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PUB_LEARNING_RATE'])
    step_size = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['STEP_SIZE'])
    gamma = float(ensemble_model_config['{}_{}'.format(data_name, model_name)]['GAMMA'])
    num_class = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = ensemble_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']

    private_model_path_1 = "models/ensemble/base_{}_{}_1.pth".format(data_name, model_name)
    private_model_path_2 = "models/ensemble/base_{}_{}_2.pth".format(data_name, model_name)
    private_model_path_3 = "models/ensemble/base_{}_{}_3.pth".format(data_name, model_name)
    public_model_path = "models/ensemble/ensemble_protected_{}_{}.pth".format(data_name, model_name)

    # In this single machine situation, all processes have access to all data,
    raw_data_x, raw_data_y = globals()[data_name]()
    input_shape = raw_data_x[0].shape
    if rank == 0:
        alice_dict = get_alice_split(raw_data_x, raw_data_y, data_name)
        sample_data_x_1, sample_data_y_1 = get_part_sample_split(alice_dict, data_name, 'alice')
        sample_data_x_2, sample_data_y_2 = get_part_sample_split(alice_dict, data_name, 'alice')
        sample_data_x_3, sample_data_y_3 = get_part_sample_split(alice_dict, data_name, 'alice')
        sample_data_y_1 = torch.eye(num_class)[sample_data_y_1]
        sample_data_y_2 = torch.eye(num_class)[sample_data_y_2]
        sample_data_y_3 = torch.eye(num_class)[sample_data_y_3]
        data_x, data_y = alice_dict["train"]
        data_y = torch.eye(num_class)[data_y]
        ref_x, ref_y = alice_dict["ref"]
        ref_y = torch.eye(num_class)[ref_y]
        test_x, test_y = alice_dict["test"]
        test_y = torch.eye(num_class)[test_y]
    else:
        bob_dict = get_bob_split(raw_data_x, raw_data_y, data_name)
        sample_data_x_1, sample_data_y_1 = get_part_sample_split(bob_dict, data_name, 'bob')
        sample_data_x_2, sample_data_y_2 = get_part_sample_split(bob_dict, data_name, 'bob')
        sample_data_x_3, sample_data_y_3 = get_part_sample_split(bob_dict, data_name, 'bob')
        sample_data_y_1 = torch.eye(num_class)[sample_data_y_1]
        sample_data_y_2 = torch.eye(num_class)[sample_data_y_2]
        sample_data_y_3 = torch.eye(num_class)[sample_data_y_3]
        data_x, data_y = bob_dict["train"]
        data_y = torch.eye(num_class)[data_y]
        ref_x, ref_y = bob_dict["ref"]
        ref_y = torch.eye(num_class)[ref_y]
        test_x, test_y = bob_dict["test"]
        test_y = torch.eye(num_class)[test_y]

    # Secret share each party's own data
    alice_data_x = crypten.cryptensor(data_x, src=ALICE).to(DEVICE)
    alice_data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    alice_sample_data_x_1 = crypten.cryptensor(sample_data_x_1, src=ALICE).to(DEVICE)
    alice_sample_data_x_2 = crypten.cryptensor(sample_data_x_2, src=ALICE).to(DEVICE)
    alice_sample_data_x_3 = crypten.cryptensor(sample_data_x_3, src=ALICE).to(DEVICE)
    alice_sample_data_y_1 = crypten.cryptensor(sample_data_y_1, src=ALICE).to(DEVICE)
    alice_sample_data_y_2 = crypten.cryptensor(sample_data_y_2, src=ALICE).to(DEVICE)
    alice_sample_data_y_3 = crypten.cryptensor(sample_data_y_3, src=ALICE).to(DEVICE)

    bob_data_x = crypten.cryptensor(data_x, src=BOB).to(DEVICE)
    bob_data_y = crypten.cryptensor(data_y, src=BOB).to(DEVICE)
    bob_sample_data_x_1 = crypten.cryptensor(sample_data_x_1, src=ALICE).to(DEVICE)
    bob_sample_data_x_2 = crypten.cryptensor(sample_data_x_2, src=ALICE).to(DEVICE)
    bob_sample_data_x_3 = crypten.cryptensor(sample_data_x_3, src=ALICE).to(DEVICE)
    bob_sample_data_y_1 = crypten.cryptensor(sample_data_y_1, src=ALICE).to(DEVICE)
    bob_sample_data_y_2 = crypten.cryptensor(sample_data_y_2, src=ALICE).to(DEVICE)
    bob_sample_data_y_3 = crypten.cryptensor(sample_data_y_3, src=ALICE).to(DEVICE)

    alice_ref_x = crypten.cryptensor(ref_x, src=ALICE).to(DEVICE)
    alice_ref_y = crypten.cryptensor(ref_y, src=ALICE).to(DEVICE)
    bob_ref_x = crypten.cryptensor(ref_x, src=BOB).to(DEVICE)
    bob_ref_y = crypten.cryptensor(ref_y, src=BOB).to(DEVICE)

    alice_test_x = crypten.cryptensor(test_x, src=ALICE).to(DEVICE)
    alice_test_y = crypten.cryptensor(test_y, src=ALICE).to(DEVICE)

    bob_test_x = crypten.cryptensor(test_x, src=BOB).to(DEVICE)
    bob_test_y = crypten.cryptensor(test_y, src=BOB).to(DEVICE)

    data_x_enc = crypten.cat([alice_data_x, bob_data_x], dim=0).to(DEVICE)
    data_y_enc = crypten.cat([alice_data_y, bob_data_y], dim=0).to(DEVICE)
    ref_x_enc = crypten.cat([alice_ref_x, bob_ref_x], dim=0).to(DEVICE)
    ref_y_enc = crypten.cat([alice_ref_y, bob_ref_y], dim=0).to(DEVICE)
    test_x_enc = crypten.cat([alice_test_x, bob_test_x], dim=0).to(DEVICE)
    test_y_enc = crypten.cat([alice_test_y, bob_test_y], dim=0).to(DEVICE)

    sample_data_x_1_enc = crypten.cat([alice_sample_data_x_1, bob_sample_data_x_1], dim=0).to(DEVICE)
    sample_data_y_1_enc = crypten.cat([alice_sample_data_y_1, bob_sample_data_y_1], dim=0).to(DEVICE)
    sample_data_x_2_enc = crypten.cat([alice_sample_data_x_2, bob_sample_data_x_2], dim=0).to(DEVICE)
    sample_data_y_2_enc = crypten.cat([alice_sample_data_y_2, bob_sample_data_y_2], dim=0).to(DEVICE)
    sample_data_x_3_enc = crypten.cat([alice_sample_data_x_3, bob_sample_data_x_3], dim=0).to(DEVICE)
    sample_data_y_3_enc = crypten.cat([alice_sample_data_y_3, bob_sample_data_y_3], dim=0).to(DEVICE)

    dummy_input = torch.empty([1] + list(input_shape))

    # train private model encrypted
    if os.path.exists(private_model_path_1) and not START_NEW:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_1_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_1_state_dict = torch.load(private_model_path_1)
        model_pri_1_enc.load_state_dict(model_pri_1_state_dict)
        model_pri_1_enc.encrypt(src=ALICE)
        model_pri_1_enc = model_pri_1_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载基学习器1!')
    else:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_1_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_1_enc.encrypt(src=ALICE)
        model_pri_1_enc = model_pri_1_enc.to(DEVICE)
        private_train_encrypted(sample_data_x_1_enc, sample_data_y_1_enc, model_pri_1_enc, pri_epochs, batch_size,
                                pri_learning_rate,
                                step_size, gamma, logger, save_path=private_model_path_1)

    if os.path.exists(private_model_path_2) and not START_NEW:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_2_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_2_state_dict = torch.load(private_model_path_2)
        model_pri_2_enc.load_state_dict(model_pri_2_state_dict)
        model_pri_2_enc.encrypt(src=ALICE)
        model_pri_2_enc = model_pri_2_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载基学习器2!')
    else:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_2_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_2_enc.encrypt(src=ALICE)
        model_pri_2_enc = model_pri_2_enc.to(DEVICE)
        private_train_encrypted(sample_data_x_2_enc, sample_data_y_2_enc, model_pri_2_enc, pri_epochs, batch_size,
                                pri_learning_rate,
                                step_size, gamma, logger, save_path=private_model_path_2)

    if os.path.exists(private_model_path_3) and not START_NEW:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_3_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_3_state_dict = torch.load(private_model_path_3)
        model_pri_3_enc.load_state_dict(model_pri_3_state_dict)
        model_pri_3_enc.encrypt(src=ALICE)
        model_pri_3_enc = model_pri_3_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载基学习器3!')
    else:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_3_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_3_enc.encrypt(src=ALICE)
        model_pri_3_enc = model_pri_3_enc.to(DEVICE)
        private_train_encrypted(sample_data_x_3_enc, sample_data_y_3_enc, model_pri_3_enc, pri_epochs, batch_size,
                                pri_learning_rate,
                                step_size, gamma, logger, save_path=private_model_path_3)

    # test private model's accuracy on test data
    if rank == 0:
        logger.info('测试基学习器准确度！')
        logger.info('测试基学习器1！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_1_enc, logger)
    if rank == 0:
        logger.info('测试基学习器2！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_2_enc, logger)
    if rank == 0:
        logger.info('测试基学习器3！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_3_enc, logger)

    pri_predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, model_pri_1_enc, 1,
                          logger)
    pri_predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, model_pri_2_enc, 2,
                          logger)
    pri_predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, model_pri_3_enc, 3,
                          logger)

    get_final_train_data(data_name, model_name, logger)

    ref_pred = torch.load("results/ensemble/final_train_pred_{}_{}.pth".format(data_name, model_name))
    ref_pred_enc = crypten.cryptensor(ref_pred, src=ALICE).to(DEVICE)
    # ref_data_x, ref_data_y = get_ref(raw_data_x, raw_data_y, data_name)
    # print((torch.argmax(ref_pred, dim=1) == ref_data_y).sum())

    # train public model encrypted
    model_pub = globals()[model_name](input_shape, num_class, init_method)
    model_pub_enc = crypten.nn.from_pytorch(model_pub, dummy_input)
    # model_pub_state_dict = torch.load(public_model_path)
    # model_pub_enc.load_state_dict(model_pub_state_dict)
    model_pub_enc.encrypt(src=ALICE)
    model_pub_enc = model_pub_enc.to(DEVICE)
    if pub_pre_epochs > 0:
        private_train_encrypted(data_x_enc, data_y_enc, model_pub_enc, pub_pre_epochs, batch_size, pri_learning_rate,
                                step_size, gamma, logger)
    public_train_encrypted(ref_x_enc, ref_pred_enc, model_pub_enc, pub_epochs, batch_size, pub_learning_rate,
                           step_size, gamma, logger, save_path=public_model_path)

    # test public model's accuracy on test data
    test_encrypted(test_x_enc, test_y_enc, model_pub_enc, logger)

    pub_predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, num_class, init_method, logger)


def mpc_ensemble_train(data_name, model_name):
    rank = comm.get().get_rank()

    # Read ensemble model's train parameters
    ensemble_model_config = configparser.ConfigParser()
    ensemble_model_config.read('ensemble_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_ensemble_train start!')

    pri_epochs = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PRI_EPOCHS'])
    batch_size = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['BATCH_SIZE'])
    pri_learning_rate = float(ensemble_model_config['{}_{}'.format(data_name, model_name)]['PRI_LEARNING_RATE'])
    step_size = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['STEP_SIZE'])
    gamma = float(ensemble_model_config['{}_{}'.format(data_name, model_name)]['GAMMA'])
    num_class = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = ensemble_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']

    private_model_path_1 = "models/ensemble/base_{}_{}_1.pth".format(data_name, model_name)
    private_model_path_2 = "models/ensemble/base_{}_{}_2.pth".format(data_name, model_name)
    private_model_path_3 = "models/ensemble/base_{}_{}_3.pth".format(data_name, model_name)

    # In this single machine situation, all processes have access to all data,
    raw_data_x, raw_data_y = globals()[data_name]()
    input_shape = raw_data_x[0].shape
    if rank == 0:
        alice_dict = get_alice_split(raw_data_x, raw_data_y, data_name)
        sample_data_x_1, sample_data_y_1 = get_part_sample_split(alice_dict, data_name, 'alice')
        sample_data_x_2, sample_data_y_2 = get_part_sample_split(alice_dict, data_name, 'alice')
        sample_data_x_3, sample_data_y_3 = get_part_sample_split(alice_dict, data_name, 'alice')
        sample_data_y_1 = torch.eye(num_class)[sample_data_y_1]
        sample_data_y_2 = torch.eye(num_class)[sample_data_y_2]
        sample_data_y_3 = torch.eye(num_class)[sample_data_y_3]
        test_x, test_y = alice_dict["test"]
        test_y = torch.eye(num_class)[test_y]
    else:
        bob_dict = get_bob_split(raw_data_x, raw_data_y, data_name)
        sample_data_x_1, sample_data_y_1 = get_part_sample_split(bob_dict, data_name, 'bob')
        sample_data_x_2, sample_data_y_2 = get_part_sample_split(bob_dict, data_name, 'bob')
        sample_data_x_3, sample_data_y_3 = get_part_sample_split(bob_dict, data_name, 'bob')
        sample_data_y_1 = torch.eye(num_class)[sample_data_y_1]
        sample_data_y_2 = torch.eye(num_class)[sample_data_y_2]
        sample_data_y_3 = torch.eye(num_class)[sample_data_y_3]
        test_x, test_y = bob_dict["test"]
        test_y = torch.eye(num_class)[test_y]

    # Secret share each party's own data
    alice_sample_data_x_1 = crypten.cryptensor(sample_data_x_1, src=ALICE).to(DEVICE)
    alice_sample_data_x_2 = crypten.cryptensor(sample_data_x_2, src=ALICE).to(DEVICE)
    alice_sample_data_x_3 = crypten.cryptensor(sample_data_x_3, src=ALICE).to(DEVICE)
    alice_sample_data_y_1 = crypten.cryptensor(sample_data_y_1, src=ALICE).to(DEVICE)
    alice_sample_data_y_2 = crypten.cryptensor(sample_data_y_2, src=ALICE).to(DEVICE)
    alice_sample_data_y_3 = crypten.cryptensor(sample_data_y_3, src=ALICE).to(DEVICE)

    bob_sample_data_x_1 = crypten.cryptensor(sample_data_x_1, src=ALICE).to(DEVICE)
    bob_sample_data_x_2 = crypten.cryptensor(sample_data_x_2, src=ALICE).to(DEVICE)
    bob_sample_data_x_3 = crypten.cryptensor(sample_data_x_3, src=ALICE).to(DEVICE)
    bob_sample_data_y_1 = crypten.cryptensor(sample_data_y_1, src=ALICE).to(DEVICE)
    bob_sample_data_y_2 = crypten.cryptensor(sample_data_y_2, src=ALICE).to(DEVICE)
    bob_sample_data_y_3 = crypten.cryptensor(sample_data_y_3, src=ALICE).to(DEVICE)

    alice_test_x = crypten.cryptensor(test_x, src=ALICE).to(DEVICE)
    alice_test_y = crypten.cryptensor(test_y, src=ALICE).to(DEVICE)

    bob_test_x = crypten.cryptensor(test_x, src=BOB).to(DEVICE)
    bob_test_y = crypten.cryptensor(test_y, src=BOB).to(DEVICE)

    test_x_enc = crypten.cat([alice_test_x, bob_test_x], dim=0).to(DEVICE)
    test_y_enc = crypten.cat([alice_test_y, bob_test_y], dim=0).to(DEVICE)

    sample_data_x_1_enc = crypten.cat([alice_sample_data_x_1, bob_sample_data_x_1], dim=0).to(DEVICE)
    sample_data_y_1_enc = crypten.cat([alice_sample_data_y_1, bob_sample_data_y_1], dim=0).to(DEVICE)
    sample_data_x_2_enc = crypten.cat([alice_sample_data_x_2, bob_sample_data_x_2], dim=0).to(DEVICE)
    sample_data_y_2_enc = crypten.cat([alice_sample_data_y_2, bob_sample_data_y_2], dim=0).to(DEVICE)
    sample_data_x_3_enc = crypten.cat([alice_sample_data_x_3, bob_sample_data_x_3], dim=0).to(DEVICE)
    sample_data_y_3_enc = crypten.cat([alice_sample_data_y_3, bob_sample_data_y_3], dim=0).to(DEVICE)

    dummy_input = torch.empty([1] + list(input_shape))

    # train private model encrypted
    if os.path.exists(private_model_path_1) and not START_NEW:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_1_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_1_state_dict = torch.load(private_model_path_1)
        model_pri_1_enc.load_state_dict(model_pri_1_state_dict)
        model_pri_1_enc.encrypt(src=ALICE)
        model_pri_1_enc = model_pri_1_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载基学习器1!')
    else:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_1_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_1_enc.encrypt(src=ALICE)
        model_pri_1_enc = model_pri_1_enc.to(DEVICE)
        private_train_encrypted(sample_data_x_1_enc, sample_data_y_1_enc, model_pri_1_enc, pri_epochs, batch_size,
                                pri_learning_rate,
                                step_size, gamma, logger, save_path=private_model_path_1)

    if os.path.exists(private_model_path_2) and not START_NEW:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_2_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_2_state_dict = torch.load(private_model_path_2)
        model_pri_2_enc.load_state_dict(model_pri_2_state_dict)
        model_pri_2_enc.encrypt(src=ALICE)
        model_pri_2_enc = model_pri_2_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载基学习器2!')
    else:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_2_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_2_enc.encrypt(src=ALICE)
        model_pri_2_enc = model_pri_2_enc.to(DEVICE)
        private_train_encrypted(sample_data_x_2_enc, sample_data_y_2_enc, model_pri_2_enc, pri_epochs, batch_size,
                                pri_learning_rate,
                                step_size, gamma, logger, save_path=private_model_path_2)

    if os.path.exists(private_model_path_3) and not START_NEW:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_3_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_3_state_dict = torch.load(private_model_path_3)
        model_pri_3_enc.load_state_dict(model_pri_3_state_dict)
        model_pri_3_enc.encrypt(src=ALICE)
        model_pri_3_enc = model_pri_3_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载基学习器3!')
    else:
        model_pri = globals()[model_name](input_shape, num_class, init_method)
        model_pri_3_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_3_enc.encrypt(src=ALICE)
        model_pri_3_enc = model_pri_3_enc.to(DEVICE)
        private_train_encrypted(sample_data_x_3_enc, sample_data_y_3_enc, model_pri_3_enc, pri_epochs, batch_size,
                                pri_learning_rate,
                                step_size, gamma, logger, save_path=private_model_path_3)

    # test private model's accuracy on test data
    if rank == 0:
        logger.info('测试基学习器准确度！')
        logger.info('测试基学习器1！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_1_enc, logger)
    if rank == 0:
        logger.info('测试基学习器2！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_2_enc, logger)
    if rank == 0:
        logger.info('测试基学习器3！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_3_enc, logger)


def private_train_encrypted(data_x_enc, data_y_enc, model_enc, num_epochs, batch_size, learning_rate, step_size, gamma,
                            logger, save_path=None):
    rank = comm.get().get_rank()
    loss_fn = crypten.nn.CrossEntropyLoss()
    num_samples = data_x_enc.shape[0]
    model_enc.train()

    for epoch in range(num_epochs):

        correct_count = 0
        loss_count = 0
        if epoch + 1 % step_size == 0:
            learning_rate *= gamma

        for index in range(0, num_samples, batch_size):
            # Get data batch
            start, end = index, min(index + batch_size, num_samples)
            x_train = data_x_enc[start:end]
            y_train = data_y_enc[start:end]
            x_train.requires_grad = True
            y_train.requires_grad = True

            # forward propagation
            output = model_enc(x_train)
            loss_value = loss_fn(output, y_train)

            # backward propagation
            model_enc.zero_grad()
            loss_value.backward()
            model_enc.update_parameters(learning_rate)

            # Compute model's accuracy in this epoch
            # Only use this in test environment
            pred = output.get_plain_text().argmax(1)
            data_y = y_train.get_plain_text().argmax(1)
            correct_count += pred.eq(data_y).sum().float().item()
            loss_count += loss_value.get_plain_text().item()

            if rank == 0:
                logger.info(f'{index}/{num_samples} done!')
        if rank == 0:
            logger.info("Epoch: " + str(epoch + 1) + f" Accuracy: {(100 * correct_count / num_samples):>0.1f}%,"
                                                     f" Avg loss: {loss_count * batch_size / num_samples:>8f}")
        if save_path is not None and (epoch + 1) % 20 == 0:
            model_enc.decrypt()
            model_pri_state_dict = model_enc.state_dict()
            if rank == ALICE:
                num_of_path = save_path.find('.pth')
                torch.save(model_pri_state_dict, save_path[:num_of_path] + "_{}.pth".format(epoch + 1))
            model_enc.encrypt(src=ALICE)
    if save_path is not None:
        # save plain text private model
        model_enc.decrypt()
        model_pri_state_dict = model_enc.state_dict()
        if rank == ALICE:
            torch.save(model_pri_state_dict, save_path)
        model_enc.encrypt(src=ALICE)

    return model_enc


def kl_div(q_logit, p_logit):
    log_q = q_logit.log_softmax(dim=1)
    log_p = p_logit.log_softmax(dim=1)
    q = q_logit.softmax(dim=1)
    loss_all = (q * (log_q - log_p)).sum()
    loss_mean = loss_all / q_logit.shape[0]
    return loss_mean


def public_train_encrypted(data_x_enc, data_y_enc, model_enc, num_epochs, batch_size, learning_rate, step_size, gamma,
                           logger, save_path=None):
    rank = comm.get().get_rank()
    loss_fn = kl_div
    num_samples = data_x_enc.size(0)
    model_enc.train()

    for epoch in range(num_epochs):

        correct_count = 0
        loss_count = 0

        if epoch + 1 % step_size == 0:
            learning_rate *= gamma

        for index in range(0, num_samples, batch_size):
            # Get data batch
            start, end = index, min(index + batch_size, num_samples)
            x_train = data_x_enc[start:end]
            y_train = data_y_enc[start:end]
            x_train.requires_grad = True
            y_train.requires_grad = True

            # forward propagation
            output = model_enc(x_train)
            loss_value = loss_fn(output, y_train)

            # backward propagation
            model_enc.zero_grad()
            loss_value.backward()
            model_enc.update_parameters(learning_rate)

            # Compute model's accuracy in this epoch
            # Only use this in test environment
            pred = output.get_plain_text().argmax(1)
            data_y = y_train.get_plain_text().argmax(1)
            correct_count += pred.eq(data_y).sum().float().item()
            loss_count += loss_value.get_plain_text().item()

            if rank == 0:
                logger.info(f'{index}/{num_samples} done!')
        if rank == 0:
            logger.info("Epoch: " + str(epoch + 1) + f" Accuracy: {(100 * correct_count / num_samples):>0.1f}%,"
                                                     f" Avg loss: {loss_count * batch_size / num_samples:>8f}")
        if save_path is not None:
            # save plain text private model
            model_enc.decrypt()
            model_pri_state_dict = model_enc.state_dict()
            pri_num = save_path.find('ensemble/') + len('ensemble')
            mid_num = save_path.find('.pth')
            if epoch + 1 < 10:
                end_path = f'_epoch[0{epoch + 1}]_acc[{(100 * correct_count / num_samples):>0.1f}]_loss[{loss_count * batch_size / num_samples:>8f}].pth'
            else:
                end_path = f'_epoch[{epoch + 1}]_acc[{(100 * correct_count / num_samples):>0.1f}]_loss[{loss_count * batch_size / num_samples:>8f}].pth'
            path = save_path[:pri_num] + '/ensemble_models' + save_path[pri_num:mid_num] + end_path
            if rank == ALICE:
                if epoch + 1 == num_epochs:
                    torch.save(model_pri_state_dict, save_path)
                torch.save(model_pri_state_dict, path)
            model_enc.encrypt(src=ALICE)
    return model_enc


def test_encrypted(data_x_enc, data_y_enc, model_enc, logger):
    rank = comm.get().get_rank()
    num_samples = data_x_enc.shape[0]
    model_enc.eval()

    correct_count = 0
    for index in range(0, num_samples, 128):
        # Get data batch
        start, end = index, min(index + 128, num_samples)
        x_train = data_x_enc[start:end]
        y_train = data_y_enc[start:end]

        # forward propagation
        output = model_enc(x_train)

        # compute accuracy
        pred = output.get_plain_text().argmax(1)
        data_y = y_train.get_plain_text().argmax(1)
        correct_count += pred.eq(data_y).sum().float().item()

        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    if rank == 0:
        logger.info(f"Test accuracy: {(100 * correct_count / num_samples):>0.1f}%")


def eval_encrypted(data_x_enc, model_enc, logger):
    rank = comm.get().get_rank()
    model_enc.eval()
    num_samples = data_x_enc.shape[0]
    outputs = []
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]

        # forward propagation
        output = model_enc(x_train)
        outputs.append(output)
        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    return crypten.cat(outputs, dim=0)


def pri_predict_encrypted(data_x, data_y, data_name, model_name, model_enc, number, logger):
    rank = comm.get().get_rank()
    if rank == 0:
        logger.info('pri_predict_encrypted start!')

    # load trained data and ref data
    input_shape = data_x[0].shape
    train_data_x, train_data_y = get_ref(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE)
    train_x_enc = train_x_enc.to(DEVICE)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/ensemble/ensemble_train_pred_{}_{}_{}.pth".format(data_name, model_name, number)
    train_y_path = "results/ensemble/ensemble_train_y_{}_{}_{}.pth".format(data_name, model_name, number)
    torch.save(train_output, train_pred_path)
    torch.save(train_data_y, train_y_path)


def pub_predict_encrypted(data_x, data_y, data_name, model_name, num_class, init_method, logger):
    rank = comm.get().get_rank()
    if rank == 0:
        logger.info('pub_predict_encrypted start!')

    # load data need to be predicted
    input_shape = data_x[0].shape

    # load trained data and ref data
    train_data_x, train_data_y = get_train_predict_split(data_x, data_y, data_name)
    ref_data_x, ref_data_y = get_ref_predict_split(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE).to(DEVICE)
    ref_x_enc = crypten.cryptensor(ref_data_x, src=ALICE).to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/ensemble/ensemble_protected_{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()
    ref_output_enc = eval_encrypted(ref_x_enc, model_enc, logger)
    ref_output = ref_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/ensemble/ensemble_train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/ensemble/ensemble_train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)
    ref_pred_path = "results/ensemble/ensemble_ref_pred_{}_{}.pth".format(data_name, model_name)
    ref_y_path = "results/ensemble/ensemble_ref_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(ref_output, dim=1), ref_pred_path)
    torch.save(ref_data_y, ref_y_path)


def get_final_train_data(data_name, model_name, logger):
    rank = comm.get().get_rank()
    model_1 = torch.load("results/ensemble/ensemble_train_pred_{}_{}_1.pth".format(data_name, model_name),
                         map_location=torch.device('cpu'))
    data_y = torch.load("results/ensemble/ensemble_train_y_{}_{}_1.pth".format(data_name, model_name),
                        map_location=torch.device('cpu'))
    model_2 = torch.load("results/ensemble/ensemble_train_pred_{}_{}_2.pth".format(data_name, model_name),
                         map_location=torch.device('cpu'))
    model_3 = torch.load("results/ensemble/ensemble_train_pred_{}_{}_3.pth".format(data_name, model_name),
                         map_location=torch.device('cpu'))

    name_of_models = ['model1', 'model2', 'model3']
    num_flag = [1, 2, 4, 8, 16]
    outputs = dict()
    outputs[name_of_models[0]] = model_1.cpu()
    outputs[name_of_models[1]] = model_2.cpu()
    outputs[name_of_models[2]] = model_3.cpu()
    outputs_flag = dict()
    for name in outputs.keys():
        outputs_flag[name] = torch.argmax(outputs[name], dim=1) == data_y
    flag = torch.zeros(10000)
    num = 0
    for name in outputs_flag.keys():
        for idx in range(len(outputs[name])):
            if outputs_flag[name][idx].item():
                flag[idx] += num_flag[num]
        num += 1
    data_pre = torch.zeros(model_1.size()[0], model_1.size()[1])
    for idx in range(len(model_1)):
        if flag[idx] == 7:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[1]][idx] + outputs[name_of_models[0]][
                idx]) / 3.0
        elif flag[idx] == 6:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[1]][idx]) / 2.0
        elif flag[idx] == 5:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[0]][idx]) / 2.0
        elif flag[idx] == 4:
            data_pre[idx] = outputs[name_of_models[2]][idx]
        elif flag[idx] == 3:
            data_pre[idx] = (outputs[name_of_models[1]][idx] + outputs[name_of_models[0]][idx]) / 2.0
        elif flag[idx] == 2:
            data_pre[idx] = outputs[name_of_models[1]][idx]
        elif flag[idx] == 1:
            data_pre[idx] = outputs[name_of_models[0]][idx]
        elif flag[idx] == 0:
            data_pre[idx] = (outputs[name_of_models[2]][idx] + outputs[name_of_models[1]][idx] + outputs[name_of_models[0]][
                idx]) / 3.0
    # data_pre = F.softmax(data_pre, dim=1)
    if rank == 0:
        train_pred_path = "results/ensemble/final_train_pred_{}_{}.pth".format(data_name, model_name)
        train_y_path = "results/ensemble/final_train_y_{}_{}.pth".format(data_name, model_name)
        torch.save(data_pre, train_pred_path)
        torch.save(data_y, train_y_path)
        logger.info((torch.argmax(data_pre, dim=1) == data_y).sum())


def mpc_ensemble_predict(data_name, model_name):
    rank = comm.get().get_rank()

    # Read ensemble model's parameters
    ensemble_model_config = configparser.ConfigParser()
    ensemble_model_config.read('ensemble_encode_config.ini')
    num_class = int(ensemble_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = ensemble_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_ensemble_predict start!')

    # load data need to be predicted
    data_x, data_y = globals()[data_name]()
    input_shape = data_x[0].shape

    # load trained data and ref data
    train_data_x, train_data_y = get_train_predict_split(data_x, data_y, data_name)
    ref_data_x, ref_data_y = get_ref_predict_split(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE).to(DEVICE)
    ref_x_enc = crypten.cryptensor(ref_data_x, src=ALICE).to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/ensemble/ensemble_protected_{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()
    ref_output_enc = eval_encrypted(ref_x_enc, model_enc, logger)
    ref_output = ref_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/ensemble/ensemble_train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/ensemble/ensemble_train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)
    ref_pred_path = "results/ensemble/ensemble_ref_pred_{}_{}.pth".format(data_name, model_name)
    ref_y_path = "results/ensemble/ensemble_ref_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(ref_output, dim=1), ref_pred_path)
    torch.save(ref_data_y, ref_y_path)
