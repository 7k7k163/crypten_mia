import sys
import torchmetrics

from models import *
from datasets import *
from utils import *

"""
This procedure test dnn model's vulnerability to membership inference attack by method proposed by
'Membership Inference Attacks Against Machine Learning Models (IEEE SP 2017)', and optimized by
'ML-Leaks: Model and Data Independent Membership Inference Attacks and Defenses on Machine Learning Models (NDSS 2019)'.
We test model without any defense and defense method including dmp, mem guard and domain adaptation.
"""

DATA_NAME = sys.argv[1] if len(sys.argv) > 1 else "ch_mnist"
MODEL = sys.argv[2] if len(sys.argv) > 2 else "lenet"

# read nn attack train parameters
attack_model_config = configparser.ConfigParser()
attack_model_config.read('nn_attack.ini')
A_EPOCHS = int(attack_model_config['{}_{}'.format(DATA_NAME, MODEL)]['EPOCHS'])
A_STEP_SIZE = int(attack_model_config['{}_{}'.format(DATA_NAME, MODEL)]['STEP_SIZE'])
A_NUM_CLASS = int(attack_model_config['{}_{}'.format(DATA_NAME, MODEL)]['NUM_CLASS'])
A_BATCH_SIZE = int(attack_model_config['{}_{}'.format(DATA_NAME, MODEL)]['BATCH_SIZE'])
A_LEARNING_RATE = float(attack_model_config['{}_{}'.format(DATA_NAME, MODEL)]['LEARNING_RATE'])
A_INIT_METHOD = attack_model_config['{}_{}'.format(DATA_NAME, MODEL)]['INIT_METHOD']

# read train, ref and test data ratio
dataset_config = configparser.ConfigParser()
dataset_config.read('dataset.ini')
TRAIN_RATIO = float(dataset_config[DATA_NAME]['TRAIN_RATIO'])
TEST_RATIO = float(dataset_config[DATA_NAME]['TEST_RATIO'])

SHADOW_MODEL_PATH = "models/shadow/{}_{}.hdf5".format(DATA_NAME, MODEL)
NN_ATTACK_MODEL_PATH = "models/nn/{}_{}.hdf5".format(DATA_NAME, MODEL)
START_NEW = True
# DEVICE = torch.device("cuda:0")
DEVICE = torch.device("cpu")


def attack_start():
    """
    Train NN attack model
    """
    shadow_train_test_data = torch.load("results/shadow/train_pred_{}_{}.pth".format(DATA_NAME, MODEL), map_location=DEVICE).to(DEVICE)
    shadow_train_test_pred = torch.sort(shadow_train_test_data, dim=1, descending=True).values
    train_size = round(shadow_train_test_data.shape[0] // 2)
    test_size = shadow_train_test_data.shape[0] - train_size

    # load shadow model's output on train and test data to train a nn attack model
    nn_train_data = TensorDataset(shadow_train_test_pred, torch.cat((torch.ones(train_size).to(DEVICE),
                                                                     torch.zeros(test_size).to(DEVICE)), dim=0).reshape(
        -1, 1))

    # train a nn attack model
    if not os.path.exists(NN_ATTACK_MODEL_PATH) or START_NEW:
        print("Train nn attack {} model on data {}".format(MODEL, DATA_NAME))
        nn_attack_model = nn_attack_dropout(A_NUM_CLASS, A_INIT_METHOD).to(DEVICE)
        train_nn_attack(nn_attack_model, nn_train_data, A_EPOCHS, A_STEP_SIZE, A_BATCH_SIZE, A_LEARNING_RATE)
        torch.save(nn_attack_model, NN_ATTACK_MODEL_PATH)
    else:
        nn_attack_model = torch.load(NN_ATTACK_MODEL_PATH, map_location=DEVICE).to(DEVICE)

    """
    Train no defense model and test its vulnerability to nn attack
    """
    nodefense_train_test_data = torch.load("results/nodefense/train_pred_{}_{}.pth".format(DATA_NAME, MODEL), map_location=DEVICE).to(DEVICE)
    nodefense_train_test_pred = torch.sort(nodefense_train_test_data, dim=1, descending=True).values
    train_size = round(nodefense_train_test_pred.shape[0] * TRAIN_RATIO / (TRAIN_RATIO + TEST_RATIO))
    test_size = nodefense_train_test_pred.shape[0] - train_size

    # load pruning defense model's output on train and test data to test a nn attack model
    nn_nodefense_train_test_data = TensorDataset(nodefense_train_test_pred,
                                                 torch.cat((torch.ones(train_size, dtype=torch.long).to(DEVICE),
                                                            torch.zeros(test_size, dtype=torch.long).to(DEVICE)),
                                                           dim=0).reshape(-1, 1))

    # test nn attack model's performance on nodefense model's train data
    print("NN attack on nodefense model's train data")
    test_nn_attack(nn_attack_model, nn_nodefense_train_test_data, DEVICE)

    """
    Train ensemble defense model and test its vulnerability to nn attack
    """
    ensemble_train_test_data = torch.load("results/ensemble/ensemble_train_pred_{}_{}.pth".format(DATA_NAME, MODEL), map_location=DEVICE).to(DEVICE)
    ensemble_train_test_pred = torch.sort(ensemble_train_test_data, dim=1, descending=True).values
    ensemble_ref_test_data = torch.load("results/ensemble/ensemble_ref_pred_{}_{}.pth".format(DATA_NAME, MODEL), map_location=DEVICE).to(DEVICE)
    ensemble_ref_test_pred = torch.sort(ensemble_ref_test_data, dim=1, descending=True).values

    ensemble_test_data = torch.cat([ensemble_train_test_pred[:1000], ensemble_ref_test_pred[:1000], ensemble_train_test_pred[1000:], ensemble_ref_test_pred[1000:]], dim=0)
    ensemble_test_data = torch.sort(ensemble_test_data, dim=1, descending=True).values

    train_size = round(ensemble_train_test_pred.shape[0] * TRAIN_RATIO / (TRAIN_RATIO + TEST_RATIO))
    test_size = ensemble_train_test_pred.shape[0] - train_size
    ref_size = ensemble_ref_test_pred.shape[0] - test_size

    # load ensemble model's output on train and test data to test a nn attack model
    nn_ensemble_train_test_data = TensorDataset(ensemble_train_test_pred,
                                           torch.cat((torch.ones(train_size, dtype=torch.long).to(DEVICE),
                                                      torch.zeros(test_size, dtype=torch.long).to(DEVICE)),
                                                     dim=0).reshape(-1, 1))

    # load ensemble model's output on ref and test data to test a nn attack model
    nn_ensemble_ref_test_data = TensorDataset(ensemble_ref_test_pred,
                                         torch.cat((torch.ones(ref_size, dtype=torch.long).to(DEVICE),
                                                    torch.zeros(test_size, dtype=torch.long).to(DEVICE)),
                                                   dim=0).reshape(-1, 1))

    # load ensemble model's output on all data to test a nn attack model
    nn_ensemble_test_data = TensorDataset(ensemble_test_data,
                                         torch.cat((torch.ones(ref_size * 2, dtype=torch.long).to(DEVICE),
                                                    torch.zeros(test_size * 2, dtype=torch.long).to(DEVICE)),
                                                   dim=0).reshape(-1, 1))

    # test nn attack model's performance on ensemble model's train data
    # print("NN attack on ensemble defense model's train data")
    # test_nn_attack(nn_attack_model, nn_ensemble_train_test_data, DEVICE)

    # test nn attack model's performance on ensemble model's ref data
    # print("NN attack on ensemble defense model's ref data")
    # test_nn_attack(nn_attack_model, nn_ensemble_ref_test_data, DEVICE)

    # test nn attack model's performance on ensemble model's all data
    print("NN attack on ensemble defense model's all data")
    test_nn_attack(nn_attack_model, nn_ensemble_test_data, DEVICE)


if __name__ == "__main__":
    attack_start()
