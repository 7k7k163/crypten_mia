import torch
import crypten
import crypten.communicator as comm
from datasets import *
from models import *
from utils import get_logger

ALICE = 0
BOB = 1
START_NEW = True
DEVICE = torch.device("cuda:0")


def mpc_distillation_train(data_name, model_name):
    rank = comm.get().get_rank()

    # Read distillation model's train parameters
    distillation_model_config = configparser.ConfigParser()
    distillation_model_config.read('distillation_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_distillation_train start!')


    pri_epochs = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['PRI_EPOCHS'])
    pub_epochs = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['PUB_EPOCHS'])
    pub_pre_epochs = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['PUB_PRE_EPOCHS'])
    batch_size = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['BATCH_SIZE'])
    pri_learning_rate = float(distillation_model_config['{}_{}'.format(data_name, model_name)]['PRI_LEARNING_RATE'])
    pub_learning_rate = float(distillation_model_config['{}_{}'.format(data_name, model_name)]['PUB_LEARNING_RATE'])
    step_size = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['STEP_SIZE'])
    gamma = float(distillation_model_config['{}_{}'.format(data_name, model_name)]['GAMMA'])
    num_class = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = distillation_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    teacher_model = distillation_model_config['{}_{}'.format(data_name, model_name)]['teacher_model']
    student_model = distillation_model_config['{}_{}'.format(data_name, model_name)]['student_model']

    private_model_path = "models/distillation/teacher_{}_{}.pth".format(data_name, model_name)
    public_model_path = "models/distillation/student_{}_{}.pth".format(data_name, model_name)

    # In this single machine situation, all processes have access to all data,
    raw_data_x, raw_data_y = globals()[data_name]()
    input_shape = raw_data_x[0].shape
    if rank == 0:
        alice_dict = get_alice_split(raw_data_x, raw_data_y, data_name)
        data_x, data_y = alice_dict["train"]
        data_y = torch.eye(num_class)[data_y]
        ref_x, ref_y = alice_dict["ref"]
        test_x, test_y = alice_dict["test"]
        test_y = torch.eye(num_class)[test_y]
    else:
        bob_dict = get_bob_split(raw_data_x, raw_data_y, data_name)
        data_x, data_y = bob_dict["train"]
        data_y = torch.eye(num_class)[data_y]
        ref_x, ref_y = bob_dict["ref"]
        test_x, test_y = bob_dict["test"]
        test_y = torch.eye(num_class)[test_y]

    # Secret share each party's own data
    alice_data_x = crypten.cryptensor(data_x, src=ALICE)
    alice_data_y = crypten.cryptensor(data_y, src=ALICE)

    bob_data_x = crypten.cryptensor(data_x, src=BOB)
    bob_data_y = crypten.cryptensor(data_y, src=BOB)

    alice_ref_x = crypten.cryptensor(ref_x, src=ALICE)
    bob_ref_x = crypten.cryptensor(ref_x, src=BOB)

    alice_test_x = crypten.cryptensor(test_x, src=ALICE)
    alice_test_y = crypten.cryptensor(test_y, src=ALICE)

    bob_test_x = crypten.cryptensor(test_x, src=BOB)
    bob_test_y = crypten.cryptensor(test_y, src=BOB)

    data_x_enc = crypten.cat([alice_data_x, bob_data_x], dim=0).to(DEVICE)
    data_y_enc = crypten.cat([alice_data_y, bob_data_y], dim=0).to(DEVICE)
    ref_x_enc = crypten.cat([alice_ref_x, bob_ref_x], dim=0).to(DEVICE)
    test_x_enc = crypten.cat([alice_test_x, bob_test_x], dim=0).to(DEVICE)
    test_y_enc = crypten.cat([alice_test_y, bob_test_y], dim=0).to(DEVICE)

    dummy_input = torch.empty([1] + list(input_shape))

    # train private model encrypted
    if os.path.exists(private_model_path) and not START_NEW:
        model_pri = globals()[teacher_model](input_shape, num_class, init_method)
        model_pri_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_state_dict = torch.load(private_model_path)
        model_pri_enc.load_state_dict(model_pri_state_dict)
        model_pri_enc.encrypt(src=ALICE)
        model_pri_enc = model_pri_enc.to(DEVICE)
        if rank == 0:
            logger.info('加载私人模型!!')
    else:
        model_pri = globals()[teacher_model](input_shape, num_class, init_method)
        model_pri_enc = crypten.nn.from_pytorch(model_pri, dummy_input)
        model_pri_enc.encrypt(src=ALICE)
        model_pri_enc = model_pri_enc.to(DEVICE)
        private_train_encrypted(data_x_enc, data_y_enc, model_pri_enc, pri_epochs, batch_size, pri_learning_rate, step_size, gamma, logger, save_path=private_model_path)

    # test private model's accuracy on test data
    if rank == 0:
        logger.info('测试私人模型准确度！')
    test_encrypted(test_x_enc, test_y_enc, model_pri_enc, logger)

    # inference on ref data
    if rank == 0:
        logger.info('获得ref预测数据！')
    ref_pred_enc = eval_encrypted(ref_x_enc, model_pri_enc, logger).to(DEVICE)

    # train public model encrypted
    model_pub = globals()[student_model](input_shape, num_class, init_method)
    model_pub_enc = crypten.nn.from_pytorch(model_pub, dummy_input)
    # model_pub_state_dict = torch.load(public_model_path)
    # model_pub_enc.load_state_dict(model_pub_state_dict)
    model_pub_enc.encrypt(src=ALICE)
    model_pub_enc = model_pub_enc.to(DEVICE)
    if pub_pre_epochs > 0:
        private_train_encrypted(data_x_enc, data_y_enc, model_pub_enc, pub_pre_epochs, batch_size, pri_learning_rate, step_size, gamma, logger)
    public_train_encrypted(ref_x_enc, ref_pred_enc, model_pub_enc, pub_epochs, batch_size, pub_learning_rate,
                           step_size, gamma, logger, save_path=public_model_path)

    # test public model's accuracy on test data
    test_encrypted(test_x_enc, test_y_enc, model_pub_enc, logger)

    predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, student_model, num_class, init_method, logger)


def private_train_encrypted(data_x_enc, data_y_enc, model_enc, num_epochs, batch_size, learning_rate, step_size, gamma, logger, save_path=None):

    rank = comm.get().get_rank()
    loss_fn = crypten.nn.CrossEntropyLoss()
    num_samples = data_x_enc.shape[0]
    model_enc.train()

    for epoch in range(num_epochs):

        correct_count = 0
        loss_count = 0
        if epoch + 1 % step_size == 0:
            learning_rate *= gamma

        for index in range(0, num_samples, batch_size):

            # Get data batch
            start, end = index, min(index + batch_size, num_samples)
            x_train = data_x_enc[start:end]
            y_train = data_y_enc[start:end]
            x_train.requires_grad = True
            y_train.requires_grad = True

            # forward propagation
            output = model_enc(x_train)
            loss_value = loss_fn(output, y_train)

            # backward propagation
            model_enc.zero_grad()
            loss_value.backward()
            model_enc.update_parameters(learning_rate)

            # Compute model's accuracy in this epoch
            # Only use this in test environment
            pred = output.get_plain_text().argmax(1)
            data_y = y_train.get_plain_text().argmax(1)
            correct_count += pred.eq(data_y).sum().float().item()
            loss_count += loss_value.get_plain_text().item()

            logger.info(f'{index}/{num_samples} done!')

        if rank == 0:
            logger.info("Epoch: " + str(epoch + 1) + f" Accuracy: {(100 * correct_count / num_samples):>0.1f}%,"
                                               f" Avg loss: {loss_count * batch_size / num_samples:>8f}")

        # if save_path is not None and (epoch + 1) % 20 == 0:
        #     model_enc.decrypt()
        #     model_pri_state_dict = model_enc.state_dict()
        #     if rank == ALICE:
        #         num_of_path = save_path.find('.pth')
        #         # torch.save(model_pri_state_dict, save_path[:num_of_path] + "_{}.pth".format(epoch + 1))
        #     model_enc.encrypt(src=ALICE)

    if save_path is not None:
        # min_loss = loss_count * batch_size / num_samples
        # save plain text private model
        model_enc.decrypt()
        model_pri_state_dict = model_enc.state_dict()
        if rank == ALICE:
            torch.save(model_pri_state_dict, save_path)
        model_enc.encrypt(src=ALICE)

    return model_enc


def kl_div(q_logit, p_logit):
    log_q = q_logit.log_softmax(dim=1)
    log_p = p_logit.log_softmax(dim=1)
    q = q_logit.softmax(dim=1)
    loss_all = (q * (log_q - log_p)).sum()
    loss_mean = loss_all / q_logit.shape[0]
    return loss_mean


def public_train_encrypted(data_x_enc, data_y_enc, model_enc, num_epochs, batch_size, learning_rate, step_size, gamma, logger, save_path=None):
    rank = comm.get().get_rank()
    loss_fn = kl_div
    num_samples = data_x_enc.size(0)
    model_enc.train()
    
    for epoch in range(num_epochs):

        correct_count = 0
        loss_count = 0

        if epoch + 1 % step_size == 0:
            learning_rate *= gamma

        for index in range(0, num_samples, batch_size):
            # Get data batch
            start, end = index, min(index + batch_size, num_samples)
            x_train = data_x_enc[start:end]
            y_train = data_y_enc[start:end]
            x_train.requires_grad = True
            y_train.requires_grad = True

            # forward propagation
            output = model_enc(x_train)
            loss_value = loss_fn(output, y_train)

            # backward propagation
            model_enc.zero_grad()
            loss_value.backward()
            model_enc.update_parameters(learning_rate)

            # Compute model's accuracy in this epoch
            # Only use this in test environment
            pred = output.get_plain_text().argmax(1)
            data_y = y_train.get_plain_text().argmax(1)
            correct_count += pred.eq(data_y).sum().float().item()
            loss_count += loss_value.get_plain_text().item()

            logger.info(f'{index}/{num_samples} done!')

        if rank == 0:
            logger.info("Epoch: " + str(epoch + 1) + f" Accuracy: {(100 * correct_count / num_samples):>0.1f}%,"
                                               f" Avg loss: {loss_count * batch_size / num_samples:>8f}")

        if save_path is not None:
            # save plain text private model
            model_enc.decrypt()
            model_pri_state_dict = model_enc.state_dict()
            pri_num = save_path.find('distillation/') + len('distillation')
            mid_num = save_path.find('.pth')
            if epoch + 1 < 10:
                end_path = f'_epoch[0{epoch + 1}]_acc[{(100 * correct_count / num_samples):>0.1f}]_loss[{loss_count * batch_size / num_samples:>8f}].pth'
            else:
                end_path = f'_epoch[{epoch + 1}]_acc[{(100 * correct_count / num_samples):>0.1f}]_loss[{loss_count * batch_size / num_samples:>8f}].pth'
            path = save_path[:pri_num] + '/epoch_models' + save_path[pri_num:mid_num] + end_path
            if rank == ALICE:
                torch.save(model_pri_state_dict, save_path)
                # torch.save(model_pri_state_dict, path)
            model_enc.encrypt(src=ALICE)

    return model_enc


def test_encrypted(data_x_enc, data_y_enc, model_enc, logger):
    rank = comm.get().get_rank()
    num_samples = data_x_enc.shape[0]
    model_enc.eval()

    correct_count = 0
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]
        y_train = data_y_enc[start:end]

        # forward propagation
        output = model_enc(x_train)

        # compute accuracy
        pred = output.get_plain_text().argmax(1)
        data_y = y_train.get_plain_text().argmax(1)
        correct_count += pred.eq(data_y).sum().float().item()

        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    if rank == 0:
        logger.info(f"Test accuracy: {(100 * correct_count / num_samples):>0.1f}%")


def eval_encrypted(data_x_enc, model_enc, logger):
    rank = comm.get().get_rank()
    model_enc.eval()
    num_samples = data_x_enc.shape[0]
    outputs = []
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]

        # forward propagation
        output = model_enc(x_train)
        outputs.append(output)
        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    return crypten.cat(outputs, dim=0)


def predict_encrypted(data_x, data_y, data_name, model_name, student_model, num_class, init_method, logger):
    rank = comm.get().get_rank()
    if rank == 0:
        logger.info('predict_encrypted start!')

    # load trained data and ref data
    input_shape = data_x[0].shape
    train_data_x, train_data_y = get_train_predict_split(data_x, data_y, data_name)
    ref_data_x, ref_data_y = get_ref_predict_split(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE).to(DEVICE)
    ref_x_enc = crypten.cryptensor(ref_data_x, src=ALICE).to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/distillation/student_{}_{}.pth".format(data_name, model_name)
    model = globals()[student_model](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()
    ref_output_enc = eval_encrypted(ref_x_enc, model_enc, logger)
    ref_output = ref_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/distillation/train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/distillation/train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)
    ref_pred_path = "results/distillation/ref_pred_{}_{}.pth".format(data_name, model_name)
    ref_y_path = "results/distillation/ref_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(ref_output, dim=1), ref_pred_path)
    torch.save(ref_data_y, ref_y_path)


def mpc_distillation_predict(data_name, model_name):
    rank = comm.get().get_rank()
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_distillation_predict start!')

    # Read distillation model's parameters
    distillation_model_config = configparser.ConfigParser()
    distillation_model_config.read('distillation_config.ini')
    num_class = int(distillation_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = distillation_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    student_model = distillation_model_config['{}_{}'.format(data_name, model_name)]['student_model']

    # load data need to be predicted
    data_x, data_y = globals()[data_name]()
    input_shape = data_x[0].shape

    # load trained data and ref data
    train_data_x, train_data_y = get_train_predict_split(data_x, data_y, data_name)
    ref_data_x, ref_data_y = get_ref_predict_split(data_x, data_y, data_name)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE).to(DEVICE)
    ref_x_enc = crypten.cryptensor(ref_data_x, src=ALICE).to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/distillation/student_{}_{}.pth".format(data_name, model_name)
    model = globals()[student_model](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()
    ref_output_enc = eval_encrypted(ref_x_enc, model_enc, logger)
    ref_output = ref_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/distillation/train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/distillation/train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)
    ref_pred_path = "results/distillation/ref_pred_{}_{}.pth".format(data_name, model_name)
    ref_y_path = "results/distillation/ref_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(ref_output, dim=1), ref_pred_path)
    torch.save(ref_data_y, ref_y_path)

