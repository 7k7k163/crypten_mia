import crypten
import crypten.communicator as comm
from datasets import *
from models import *
from utils import get_logger

ALICE = 0
BOB = 1
START_NEW = True
DEVICE = torch.device("cuda:0")


def mpc_shadow_train(data_name, model_name):
    rank = comm.get().get_rank()

    # Read shadow model's train parameters
    shadow_model_config = configparser.ConfigParser()
    shadow_model_config.read('shadow_config.ini')
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_shadow_train start!')


    epochs = int(shadow_model_config['{}_{}'.format(data_name, model_name)]['EPOCHS'])
    batch_size = int(shadow_model_config['{}_{}'.format(data_name, model_name)]['BATCH_SIZE'])
    learning_rate = float(shadow_model_config['{}_{}'.format(data_name, model_name)]['LEARNING_RATE'])
    num_class = int(shadow_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = shadow_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    step_size = int(shadow_model_config['{}_{}'.format(data_name, model_name)]['STEP_SIZE'])
    gamma = float(shadow_model_config['{}_{}'.format(data_name, model_name)]['GAMMA'])

    model_path = "models/shadow/{}_{}.pth".format(data_name, model_name)

    # In this single machine situation, all processes have access to all data,
    raw_data_x, raw_data_y = globals()[data_name]()
    input_shape = raw_data_x[0].shape
    nn_dict = get_nn_split(raw_data_x, raw_data_y, data_name)
    train_x, train_y = nn_dict["train"]
    train_y = torch.eye(num_class)[train_y]
    test_x, test_y = nn_dict["test"]
    test_y = torch.eye(num_class)[test_y]

    # Secret share each party's own data
    train_x = crypten.cryptensor(train_x, src=ALICE)
    train_x = train_x.to(DEVICE)
    train_y = crypten.cryptensor(train_y, src=ALICE)
    train_y = train_y.to(DEVICE)

    test_x = crypten.cryptensor(test_x, src=ALICE)
    test_x = test_x.to(DEVICE)
    test_y = crypten.cryptensor(test_y, src=ALICE)
    test_y = test_y.to(DEVICE)

    # train shadow model encrypted
    dummy_input = torch.empty([1] + list(input_shape))
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    # model_state_dict = torch.load(model_path)
    # model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE)
    model_enc = model_enc.to(DEVICE)
    private_train_encrypted(train_x, train_y, model_enc, epochs, batch_size, learning_rate, step_size, gamma, model_path, logger)

    # test nodefense model's accuracy on test data
    test_encrypted(test_x, test_y, model_enc, logger)

    predict_encrypted(raw_data_x, raw_data_y, data_name, model_name, num_class, init_method, logger)


def private_train_encrypted(data_x_enc, data_y_enc, model_enc, num_epochs, batch_size, learning_rate, step_size, gamma, save_path, logger):

    rank = comm.get().get_rank()
    loss_fn = crypten.nn.CrossEntropyLoss()
    num_samples = data_x_enc.shape[0]
    model_enc.train()
    min_loss = 0.3

    for epoch in range(num_epochs):

        correct_count = 0
        loss_count = 0
        if epoch + 1 % step_size == 0:
            learning_rate *= gamma
        
        for index in range(0, num_samples, batch_size):

            # Get data batch
            start, end = index, min(index + batch_size, num_samples)
            x_train = data_x_enc[start:end]
            y_train = data_y_enc[start:end]
            x_train.requires_grad = True
            y_train.requires_grad = True

            # forward propagation
            output = model_enc(x_train)
            loss_value = loss_fn(output, y_train)

            # backward propagation
            model_enc.zero_grad()
            loss_value.backward()
            model_enc.update_parameters(learning_rate)

            # Compute model's accuracy in this epoch
            # Only use this in test environment
            pred = output.get_plain_text().argmax(1)
            data_y = y_train.get_plain_text().argmax(1)
            correct_count += pred.eq(data_y).sum().float().item()
            loss_count += loss_value.get_plain_text().item()

            logger.info(f'{index}/{num_samples} done!')
        if rank == 0:
            logger.info("Epoch: " + str(epoch + 1) + f" Accuracy: {(100 * correct_count / num_samples):>0.1f}%,"
                                               f" Avg loss: {loss_count * batch_size / num_samples:>8f}")
        
        if save_path is not None:
            min_loss = loss_count * batch_size / num_samples
            # save plain text private model
            model_enc.decrypt()
            model_pri_state_dict = model_enc.state_dict()
            if rank == ALICE:
                torch.save(model_pri_state_dict, save_path)
            model_enc.encrypt(src=ALICE)

    return model_enc


def test_encrypted(data_x_enc, data_y_enc, model_enc, logger):

    rank = comm.get().get_rank()
    num_samples = data_x_enc.shape[0]
    model_enc.eval()

    correct_count = 0
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]
        y_train = data_y_enc[start:end]

        # forward propagation
        output = model_enc(x_train)

        # compute accuracy
        pred = output.get_plain_text().argmax(1)
        data_y = y_train.get_plain_text().argmax(1)
        correct_count += pred.eq(data_y).sum().float().item()

        logger.info(f'{index}/{num_samples} done!')
    if rank == 0:
        logger.info(f"Test accuracy: {(100 * correct_count / num_samples):>0.1f}%")


def eval_encrypted(data_x_enc, model_enc, logger):
    rank = comm.get().get_rank()

    model_enc.eval()
    num_samples = data_x_enc.shape[0]
    outputs = []
    for index in range(0, num_samples, 64):
        # Get data batch
        start, end = index, min(index + 64, num_samples)
        x_train = data_x_enc[start:end]

        # forward propagation
        output = model_enc(x_train)
        outputs.append(output)

        if rank == 0:
            logger.info(f'{index}/{num_samples} done!')
    return crypten.cat(outputs, dim=0)


def predict_encrypted(data_x, data_y, data_name, model_name, num_class, init_method, logger):
    rank = comm.get().get_rank()
    if rank == 0:
        logger.info('predict_encrypted start!')

    # load data need to be predicted
    input_shape = data_x[0].shape
    nn_dict = get_nn_split(data_x, data_y, data_name)
    train_x, train_y = nn_dict["train"]
    test_x, test_y = nn_dict["test"]
    train_data_x = torch.cat([train_x, test_x], dim=0)
    train_data_y = torch.cat([train_y, test_y], dim=0)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE).to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/shadow/{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE).to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/shadow/train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/shadow/train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)


def mpc_shadow_predict(data_name, model_name):
    rank = comm.get().get_rank()

    # Read shadow model's parameters
    shadow_model_config = configparser.ConfigParser()
    shadow_model_config.read('shadow_config.ini')
    num_class = int(shadow_model_config['{}_{}'.format(data_name, model_name)]['NUM_CLASS'])
    init_method = shadow_model_config['{}_{}'.format(data_name, model_name)]['INIT_METHOD']
    logger = get_logger('./logger/{}_{}.log'.format(data_name, model_name))
    if rank == 0:
        logger.info('mpc_shadow_predict start!')

    # load data need to be predicted
    data_x, data_y = globals()[data_name]()
    input_shape = data_x[0].shape

    nn_dict = get_nn_split(data_x, data_y, data_name)
    train_x, train_y = nn_dict["train"]
    test_x, test_y = nn_dict["test"]
    train_data_x = torch.cat([train_x, test_x], dim=0)
    train_data_y = torch.cat([train_y, test_y], dim=0)
    train_x_enc = crypten.cryptensor(train_data_x, src=ALICE).to(DEVICE)

    # load saved model
    if rank == 0:
        logger.info('load saved model')
    dummy_input = torch.empty([1] + list(input_shape))
    model_path = "models/shadow/{}_{}.pth".format(data_name, model_name)
    model = globals()[model_name](input_shape, num_class, init_method)
    model_enc = crypten.nn.from_pytorch(model, dummy_input)
    model_state_dict = torch.load(model_path)
    model_enc.load_state_dict(model_state_dict)
    model_enc.encrypt(src=ALICE)
    model_enc = model_enc.to(DEVICE)

    # data_y = torch.eye(num_class)[train_data_y]
    # data_y = crypten.cryptensor(data_y, src=ALICE).to(DEVICE)
    # test_encrypted(train_x_enc, data_y, model_enc)

    # predict on data
    if rank == 0:
        logger.info('predict on data')
    train_output_enc = eval_encrypted(train_x_enc, model_enc, logger)
    train_output = train_output_enc.get_plain_text()

    # save output result
    if rank == 0:
        logger.info('save output result')
    train_pred_path = "results/shadow/train_pred_{}_{}.pth".format(data_name, model_name)
    train_y_path = "results/shadow/train_y_{}_{}.pth".format(data_name, model_name)
    torch.save(torch.softmax(train_output, dim=1), train_pred_path)
    torch.save(train_data_y, train_y_path)

